
// Mobile menu
const menuBtn = document.querySelector('.menu-toggle');
const nav = document.querySelector('.site-nav');
if (menuBtn && nav) {
  menuBtn.addEventListener('click', () => nav.classList.toggle('open'));
}

// Dropdown accessibility
const dropBtn = document.querySelector('.dropbtn');
if (dropBtn) {
  const drop = document.querySelector('.dropdown-content');
  dropBtn.addEventListener('click', () => {
    const open = drop.style.display === 'block';
    drop.style.display = open ? 'none' : 'block';
    dropBtn.setAttribute('aria-expanded', String(!open));
  });
  document.addEventListener('click', (e) => {
    if (!drop.contains(e.target) && e.target !== dropBtn) drop.style.display = 'none';
  });
}

// Simple poll with localStorage
function initPoll(root) {
  const id = root.dataset.pollId || 'poll';
  const form = root.querySelector('.poll-form');
  const results = root.querySelector('.poll-results');
  const bars = root.querySelector('.bars');
  const key = `poll_${id}_counts`;
  const votedKey = `poll_${id}_voted`;

  // default counts
  const defaultCounts = [10, 8, 6];
  const labels = Array.from(form.querySelectorAll('label')).map(l => l.innerText.trim());

  function getCounts() {
    try { return JSON.parse(localStorage.getItem(key)) || defaultCounts.slice(); }
    catch { return defaultCounts.slice(); }
  }
  function saveCounts(c) { localStorage.setItem(key, JSON.stringify(c)); }

  function render(c) {
    const total = c.reduce((a,b)=>a+b,0);
    bars.innerHTML = '';
    c.forEach((count, i) => {
      const pct = total ? Math.round((count/total)*100) : 0;
      const bar = document.createElement('div');
      bar.className = 'bar';
      const fill = document.createElement('div');
      fill.className = 'fill';
      fill.style.width = pct + '%';
      const label = document.createElement('div');
      label.className = 'label';
      label.textContent = `${labels[i]} — ${pct}% (${count})`;
      bar.appendChild(fill);
      bar.appendChild(label);
      bars.appendChild(bar);
    });
  }

  // Already voted?
  if (localStorage.getItem(votedKey)) {
    form.hidden = true;
    results.hidden = false;
    render(getCounts());
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const choice = form.querySelector('input[name="vote"]:checked');
    if (!choice) return;
    const idx = parseInt(choice.value, 10);
    const counts = getCounts();
    counts[idx]++;
    saveCounts(counts);
    localStorage.setItem(votedKey, '1');
    form.hidden = true;
    results.hidden = false;
    render(counts);
  });
}

document.querySelectorAll('.poll').forEach(initPoll);

// Forms — store to localStorage (demo only)
function hookForm(id, successId, storageKey) {
  const form = document.getElementById(id);
  const ok = document.getElementById(successId);
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const existing = JSON.parse(localStorage.getItem(storageKey) || '[]');
    existing.push({ ...data, ts: new Date().toISOString() });
    localStorage.setItem(storageKey, JSON.stringify(existing));
    if (ok) ok.hidden = false;
    form.reset();
  });
}
hookForm('applyForm', 'applySuccess', 'wg_applications');
hookForm('contactForm', 'contactSuccess', 'wg_contacts');
